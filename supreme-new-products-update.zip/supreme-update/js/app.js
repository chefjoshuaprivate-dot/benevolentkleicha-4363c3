// ===== PRODUCT CATALOG =====
const products = [
  // SUITCASES
  {
    id: 1,
    name: "Dark Green Hard-Shell Suitcase",
    price: 2300,
    category: "suitcases",
    image: "images/green-suitcase-2300.jpg",
    desc: "Premium travel suitcase with smooth wheels"
  },
  {
    id: 2,
    name: "Bright Blue Hard-Shell Suitcase",
    price: 3600,
    category: "suitcases",
    image: "images/blue-suitcase-3600.jpg",
    desc: "Spacious hard-shell travel suitcase"
  },
  {
    id: 3,
    name: "Suitcase Variety Collection",
    price: 2300,
    category: "suitcases",
    image: "images/suitcase-variety.jpg",
    desc: "Multiple colours & sizes available"
  },

  // BACKPACKS
  {
    id: 4,
    name: "Black Quilted Laptop Backpack",
    price: 1200,
    category: "backpacks",
    image: "images/laptop-backpack-1200.jpg",
    desc: "USB port, padded laptop compartment"
  },
  {
    id: 5,
    name: "Beige Tactical Backpack",
    price: 1700,
    category: "backpacks",
    image: "images/tactical-backpack-1700.jpg",
    desc: "Durable tactical style with multiple pockets"
  },
  {
    id: 6,
    name: "Princess Kids Backpack",
    price: 1500,
    category: "backpacks",
    image: "images/princess-backpack-1500.png",
    desc: "Cute princess design for kids"
  },
  {
    id: 7,
    name: "Crossbody Sling Bags (3 Colours)",
    price: 400,
    category: "backpacks",
    image: "images/sling-bags-400.png",
    desc: "Grey, Black & Blue available"
  },

  // HANDBAGS
  {
    id: 8,
    name: "Fluffy Pom-Pom Handbags",
    price: 600,
    category: "handbags",
    image: "images/fluffy-pom-bags-600.jpg",
    desc: "Soft fluffy bags in multiple colours"
  },
  {
    id: 9,
    name: "Pink Cat-Ear Quilted Bag",
    price: 1100,
    category: "handbags",
    image: "images/pink-cat-bag-1100.jpg",
    desc: "Cute cat-ear design with gold accents"
  },
  {
    id: 10,
    name: "Grey WENJIE Structured Handbag",
    price: 1800,
    category: "handbags",
    image: "images/grey-wenjie-bag-1800.png",
    desc: "Elegant structured handbag"
  },
  {
    id: 11,
    name: "Black Fansiman Handbag",
    price: 1800,
    category: "handbags",
    image: "images/black-fansiman-1800.png",
    desc: "Classic black structured bag"
  },
  {
    id: 12,
    name: "Black Quilted Crossbody (Gold V)",
    price: 850,
    category: "handbags",
    image: "images/black-v-crossbody-850.jpg",
    desc: "Stylish quilted crossbody with gold V"
  },
  {
    id: 13,
    name: "Mini Forever Young Crossbody",
    price: 550,
    category: "handbags",
    image: "images/mini-forever-young-550.jpg",
    desc: "Many colours available"
  },
  {
    id: 14,
    name: "Mini Chanel-Style Fur Handle Bags",
    price: 700,
    category: "handbags",
    image: "images/mini-chanel-fur-700.jpg",
    desc: "Cute mini bags with fluffy handles"
  },
  {
    id: 15,
    name: "Beige Ribbed Chain Bag",
    price: 1750,
    category: "handbags",
    image: "images/beige-chain-bag-1750.jpg",
    desc: "Elegant ribbed design with statement chain"
  },
  {
    id: 16,
    name: "Red Quilted Bag with Scarf",
    price: 1100,
    category: "handbags",
    image: "images/red-quilted-bag-1100.jpg",
    desc: "Bold red with matching scarf"
  },
  {
    id: 17,
    name: "Light Blue Heart Pattern Bag",
    price: 1100,
    category: "handbags",
    image: "images/blue-heart-bag-1100.jpg",
    desc: "Cute heart design with scarf"
  },
  {
    id: 18,
    name: "Black Tote with Pom-Pom",
    price: 1100,
    category: "handbags",
    image: "images/black-tote-pompom-1100.jpg",
    desc: "Spacious black tote with charm"
  },
  {
    id: 19,
    name: "Patterned Tote Bags Set",
    price: 800,
    category: "handbags",
    image: "images/patterned-totes-800.jpg",
    desc: "Blue, Beige & Cream designs"
  },
  {
    id: 20,
    name: "Summer Vibes Beach Totes",
    price: 750,
    category: "handbags",
    image: "images/summer-vibes-totes-750.png",
    desc: "4 beautiful summer designs"
  },
  {
    id: 21,
    name: "Grey Quilted Tote Bag",
    price: 1300,
    category: "handbags",
    image: "images/grey-quilted-tote-1300.png",
    desc: "Spacious and stylish everyday tote"
  },
  {
    id: 22,
    name: "Olive Green Quilted Crossbody",
    price: 850,
    category: "handbags",
    image: "images/olive-crossbody-850.png",
    desc: "Trendy olive green with multiple pockets"
  },
  {
    id: 23,
    name: "Victoria's Secret Navy Tote",
    price: 900,
    category: "handbags",
    image: "images/victoria-tote-900.png",
    desc: "Spacious navy tote with pouch"
  },
  {
    id: 24,
    name: "Pink Heart Quilted Crossbody",
    price: 850,
    category: "handbags",
    image: "images/pink-heart-crossbody-850.png",
    desc: "Pretty pink with heart stitching"
  },
  {
    id: 25,
    name: "Navy Travel Duffel Bag",
    price: 900,
    category: "handbags",
    image: "images/navy-duffel-900.png",
    desc: "Durable spacious travel bag"
  },

  // SHOES & SLIDES
  {
    id: 26,
    name: "Sport Sandals (Multiple Colours)",
    price: 450,
    category: "shoes",
    image: "images/sport-sandals-450.png",
    desc: "Comfortable everyday sport sandals"
  },
  {
    id: 27,
    name: "Ladies Fashion Slides",
    price: 300,
    category: "shoes",
    image: "images/ladies-slides-300.jpg",
    desc: "H-style, Bee & Bow designs"
  },
  {
    id: 28,
    name: "Girls Mary Jane Shoes",
    price: 450,
    category: "shoes",
    image: "images/girls-maryjane-450.jpg",
    desc: "Black, White & Pink available"
  },
  {
    id: 29,
    name: "Fashion Flip Flops Collection",
    price: 450,
    category: "shoes",
    image: "images/flipflops-450.png",
    desc: "Chanel-style, CAT, TikTok designs"
  },
  {
    id: 30,
    name: "Ladies Slides Collection",
    price: 300,
    category: "shoes",
    image: "images/more-slides-300.jpg",
    desc: "Multiple stylish designs"
  },
  {
    id: 31,
    name: "Ladies Ballet Flats",
    price: 450,
    category: "shoes",
    image: "images/ladies-flats-450.png",
    desc: "Comfortable pointed & round toe flats"
  },
  {
    id: 32,
    name: "LV-Style Premium Slides",
    price: 650,
    category: "shoes",
    image: "images/lv-slides-650.jpg",
    desc: "Designer-inspired slides (sizes 40-45)"
  },

  // JERSEYS
  {
    id: 33,
    name: "Football Jerseys Collection",
    price: 550,
    category: "jerseys",
    image: "images/jerseys-collection-550.jpg",
    desc: "Man City, Arsenal, Chelsea, Brazil, Kenya & more"
  },

  // ACCESSORIES
  {
    id: 34,
    name: "Satin Scarves (Multiple Designs)",
    price: 250,
    category: "accessories",
    image: "images/satin-scarves-250.jpg",
    desc: "Beautiful satin scarves for every style"
  },

  // ===== NEW PRODUCTS ADDED =====
  {
    id: 35,
    name: "Beige Structured Handbag Set",
    price: 1800,
    category: "handbags",
    image: "images/beige-handbag-set-1800.jpg",
    desc: "Elegant beige handbag with matching pouch & pom-pom charms"
  },
  {
    id: 36,
    name: "Pink Rubber Suitcase - Large",
    price: 5200,
    category: "suitcases",
    image: "images/pink-rubber-suitcase-large-5200.jpg",
    desc: "Large pink rubber suitcase with double zip"
  },
  {
    id: 37,
    name: "Pink Rubber Suitcase - Medium",
    price: 3800,
    category: "suitcases",
    image: "images/pink-rubber-suitcase-medium-3800.jpg",
    desc: "Medium pink rubber suitcase with double zip"
  },
  {
    id: 38,
    name: "Pink Rubber Suitcase - Small",
    price: 2500,
    category: "suitcases",
    image: "images/pink-rubber-suitcase-small-2500.jpg",
    desc: "Small pink rubber suitcase with double zip"
  },
  {
    id: 39,
    name: "Pink Rubber Hand Suitcase",
    price: 1500,
    category: "suitcases",
    image: "images/pink-rubber-hand-suitcase-1500.jpg",
    desc: "Pink rubber hand suitcase / beauty case"
  },
  {
    id: 40,
    name: "Blue & White Woven Tote Bag with Hat",
    price: 2000,
    category: "handbags",
    image: "images/blue-white-woven-tote-2000.jpg",
    desc: "Stylish woven tote bag with matching sun hat"
  },
  {
    id: 41,
    name: "Black & White Woven Tote Bag with Hat",
    price: 2000,
    category: "handbags",
    image: "images/black-white-woven-tote-2000.jpg",
    desc: "Stylish woven tote bag with matching sun hat"
  },
  {
    id: 42,
    name: "Large Grey Rubber Suitcase",
    price: 4800,
    category: "suitcases",
    image: "images/large-grey-rubber-suitcase-4800.jpg",
    desc: "Spacious hard-shell rubber suitcase with smooth wheels"
  },
  {
    id: 43,
    name: "Black Adidas-Style Crossbody Bag",
    price: 500,
    category: "handbags",
    image: "images/black-adidas-crossbody-500.jpg",
    desc: "Stylish black crossbody bag with multiple pockets"
  },
  {
    id: 44,
    name: "Black Blessing Crossbody Bag",
    price: 400,
    category: "handbags",
    image: "images/black-blessing-crossbody-400.jpg",
    desc: "Compact black crossbody bag with multiple pockets"
  },
  {
    id: 45,
    name: "Kids Space Astronaut Backpack",
    price: 1500,
    category: "backpacks",
    image: "images/kids-space-astronaut-backpack-1500.jpg",
    desc: "Fun space-themed school backpack for kids"
  }
  ,

  // ===== NEW ARRIVALS - November 2026 =====
  {
    id: 46,
    name: "Mesh Mary Jane Flats (3 Colours)",
    price: 1400,
    category: "shoes",
    image: "images/mesh-maryjane-1400.jpg",
    desc: "Breathable mesh Mary Jane flats - Cream, Brown & Black (Sizes 37-42)"
  },
  {
    id: 47,
    name: "Suede Mary Jane Flats with Buckle",
    price: 500,
    category: "shoes",
    image: "images/suede-maryjane-500.jpg",
    desc: "Soft suede Mary Jane with gold buckle - Multiple colours"
  },
  {
    id: 48,
    name: "Kids High-Top Sneakers",
    price: 500,
    category: "shoes",
    image: "images/kids-hightop-sneakers-500.jpg",
    desc: "Cute kids high-top sneakers - Sizes 21-30"
  },
  {
    id: 49,
    name: "White Air Force Style Sneakers",
    price: 2000,
    category: "shoes",
    image: "images/white-airforce-2000.jpg",
    desc: "Classic white sneakers - Sizes 40-45"
  },
  {
    id: 50,
    name: "Cork Sole Sandals (3 Colours)",
    price: 1050,
    category: "shoes",
    image: "images/cork-sandals-1050.jpg",
    desc: "Comfortable cork sole sandals - Black, Beige & Brown (37-42)"
  },
  {
    id: 51,
    name: "Suede Slide Sandals (4 Colours)",
    price: 1500,
    category: "shoes",
    image: "images/suede-slides-1500.jpg",
    desc: "Premium suede slides - Grey, Tan, Brown & Black"
  },
  {
    id: 52,
    name: "White Quilted Slides",
    price: 1250,
    category: "shoes",
    image: "images/white-quilted-slides-1250.jpg",
    desc: "Elegant white quilted slides"
  },
  {
    id: 53,
    name: "Fluffy Fur Slides with Gold Buckle",
    price: 600,
    category: "shoes",
    image: "images/fur-gg-slides-600.jpg",
    desc: "Soft fur slides with designer buckle - Pink, White, Brown & Black (37-42)"
  },
  {
    id: 54,
    name: "MIN MIN Tote Bags (Multiple Colours)",
    price: 1150,
    category: "handbags",
    image: "images/minmin-totes-1150.jpg",
    desc: "Stylish tote bags available in many colours"
  },
  {
    id: 55,
    name: "Fluffy Tote Bags (3 Designs)",
    price: 750,
    category: "handbags",
    image: "images/fluffy-totes-750.jpg",
    desc: "Soft fluffy totes - Rainbow, Grey & Leopard print"
  },
  {
    id: 56,
    name: "TANA Double Buckle Cork Sandals",
    price: 550,
    category: "shoes",
    image: "images/tana-cork-sandals-550.jpg",
    desc: "Comfortable patterned cork sandals - Sizes 36-41"
  },
  {
    id: 57,
    name: "Luxestep Casual Sneakers",
    price: 1500,
    category: "shoes",
    image: "images/luxestep-sneakers-1500.jpg",
    desc: "Soft lined casual sneakers - Navy, Black & Brown (Sizes 40-45)"
  },
  {
    id: 58,
    name: "Cross Strap Slides (3 Colours)",
    price: 1200,
    category: "shoes",
    image: "images/timberland-cross-slides-1200.jpg",
    desc: "Stylish cross strap slides - Black, Olive & Tan"
  },
  {
    id: 59,
    name: "Mavuno Patent Ballet Flats with Bow",
    price: 450,
    category: "shoes",
    image: "images/mavuno-ballet-450.jpg",
    desc: "Elegant patent ballet flats - Black, Nude, Sage & White (37-42)"
  },
  {
    id: 60,
    name: "Fur Slides with Gold V Logo",
    price: 850,
    category: "shoes",
    image: "images/fur-v-slides-850.jpg",
    desc: "Luxurious fur slides with gold V detail (37-42)"
  },
  {
    id: 61,
    name: "Leather Cork Sandals (3 Colours)",
    price: 1350,
    category: "shoes",
    image: "images/leather-cork-sandals-1350.jpg",
    desc: "Premium leather cork sandals - White, Black & Brown"
  },
  {
    id: 62,
    name: "ZARA Style Logo Slides",
    price: 550,
    category: "shoes",
    image: "images/zara-mk-slides-550.jpg",
    desc: "Trendy logo slides - Black, Beige & Mustard (37-42)"
  },
  {
    id: 63,
    name: "Chanel Style Fur Slides",
    price: 650,
    category: "shoes",
    image: "images/chanel-fur-slides-650.jpg",
    desc: "Black fur slides with gold logo (37-42)"
  },
  {
    id: 64,
    name: "Boyao Black Fur Slingback Mules",
    price: 1250,
    category: "shoes",
    image: "images/boyao-fur-mules-1250.jpg",
    desc: "Soft black fur slingback mules with buckle (37-42)"
  }

  ,
  {
    id: 65,
    name: "Simple Logo Slides (4 Colours)",
    price: 300,
    category: "shoes",
    image: "images/logo-slides-300.jpg",
    desc: "Comfortable everyday slides - Pink, Brown, Black & Cream (37-42)"
  },
  {
    id: 66,
    name: "Metallic Block Heel Slides",
    price: 300,
    category: "shoes",
    image: "images/metallic-heel-slides-300.jpg",
    desc: "Shiny metallic slides - Silver, Red, Grey & Gold (37-42)"
  },
  {
    id: 67,
    name: "OK Leather Slides (3 Colours)",
    price: 800,
    category: "shoes",
    image: "images/ok-leather-slides-800.jpg",
    desc: "Genuine leather texture slides - Black, Grey & Brown (40-45)"
  },
  {
    id: 68,
    name: "Kids Clogs Soft Sole",
    price: 350,
    category: "shoes",
    image: "images/kids-clogs-350.jpg",
    desc: "Comfortable kids clogs - Multiple colours (Sizes 24-35)"
  },
  {
    id: 69,
    name: "Cross Strap M Logo Slides",
    price: 800,
    category: "shoes",
    image: "images/cross-m-slides-800.jpg",
    desc: "Stylish cross strap slides - Brown, Black & Grey (40-45)"
  },
  {
    id: 70,
    name: "SUMMER Woven Tote Bags",
    price: 1500,
    category: "handbags",
    image: "images/summer-woven-totes-1500.jpg",
    desc: "Beautiful woven summer totes - 4 designs available"
  },
  {
    id: 71,
    name: "Light Blue Suitcase - Small",
    price: 2250,
    category: "suitcases",
    image: "images/blue-suitcases-set.jpg",
    desc: "Hard-shell light blue suitcase - Small size"
  },
  {
    id: 72,
    name: "Light Blue Suitcase - Medium",
    price: 3500,
    category: "suitcases",
    image: "images/blue-suitcases-set.jpg",
    desc: "Hard-shell light blue suitcase - Medium size"
  },
  {
    id: 73,
    name: "Light Blue Suitcase - Large",
    price: 4850,
    category: "suitcases",
    image: "images/blue-suitcases-set.jpg",
    desc: "Hard-shell light blue suitcase - Large size"
  },
  {
    id: 74,
    name: "Navy Blue Suitcase - Small",
    price: 2400,
    category: "suitcases",
    image: "images/navy-suitcases-set.jpg",
    desc: "Hard-shell navy blue suitcase - Small size"
  },
  {
    id: 75,
    name: "Navy Blue Suitcase - Medium",
    price: 3850,
    category: "suitcases",
    image: "images/navy-suitcases-set.jpg",
    desc: "Hard-shell navy blue suitcase - Medium size"
  },
  {
    id: 76,
    name: "Navy Blue Suitcase - Large",
    price: 5200,
    category: "suitcases",
    image: "images/navy-suitcases-set.jpg",
    desc: "Hard-shell navy blue suitcase - Large size"
  }

  ,
  {
    id: 77,
    name: "Life is Beautiful Tote Bags (6 Colours)",
    price: 800,
    category: "handbags",
    image: "images/life-is-beautiful-totes-800.jpg",
    desc: "Stylish canvas totes with matching pouch - Grey, Camel, Pink, Mauve, Black & Blue"
  }

];

// ===== RENDER PRODUCTS =====
function renderProducts(filter = "all") {
  const grid = document.getElementById("productsGrid");
  grid.innerHTML = "";

  const filtered = filter === "all" 
    ? products 
    : products.filter(p => p.category === filter);

  if (filtered.length === 0) {
    grid.innerHTML = `<p style="grid-column:1/-1;text-align:center;color:#888;padding:40px 0;">No products in this category yet.</p>`;
    return;
  }

  filtered.forEach(product => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.dataset.category = product.category;

    const message = encodeURIComponent(
      `Hello Supreme, is this ${product.name} still available?`
    );
    const waLink = `https://wa.me/254708903671?text=${message}`;

    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" class="product-img" loading="lazy" />
      <div class="product-info">
        <h3 class="product-name">${product.name}</h3>
        <div class="product-price">KSh ${product.price.toLocaleString()}</div>
        <a href="${waLink}" class="btn-shop" target="_blank" rel="noopener">SHOP NOW</a>
      </div>
    `;
    grid.appendChild(card);
  });
}

// ===== FILTER BUTTONS =====
document.getElementById("filters").addEventListener("click", (e) => {
  if (e.target.classList.contains("filter-btn")) {
    document.querySelectorAll(".filter-btn").forEach(btn => btn.classList.remove("active"));
    e.target.classList.add("active");
    renderProducts(e.target.dataset.filter);
  }
});

// ===== MOBILE MENU =====
const menuBtn = document.getElementById("menuBtn");
const mobileNav = document.getElementById("mobileNav");

menuBtn.addEventListener("click", () => {
  mobileNav.classList.toggle("open");
});

document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", () => {
    mobileNav.classList.remove("open");
  });
});

// Close menu when clicking outside
document.addEventListener("click", (e) => {
  if (!mobileNav.contains(e.target) && !menuBtn.contains(e.target)) {
    mobileNav.classList.remove("open");
  }
});

// ===== INIT =====
renderProducts("all");
